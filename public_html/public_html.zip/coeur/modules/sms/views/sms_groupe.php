 <main class="mn-inner">
                <div class="row">
               
                    <div class="col s12">
                        <div class="page-title">Importation de fichier sms groupe</div>
                    </div>
                    <div class="col s12 m12 l12">
                        <div class="card">
                            <div class="card-content">
                                <form action="/sms/chargement_sms_groupe" class="dropzone">

                                    <div class="fallback">
                                        <input name="file" type="file" name="userfile" multiple />
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>



               
            </main>
            <div class="page-footer">
                <div class="footer-grid container">
                    <div class="footer-l white">&nbsp;</div>
                   
                    <div class="footer-r white">&nbsp;</div>
                   
                </div>
            </div>



 
            