<?php

/*
 * ======================================================
 * Database Setup
 * ======================================================
 */
$DB_HOST        = "localhost";
$DB_USER        = "root";
$DB_PASSWORD    = "Magloire123";
$DATABASE       = "forever";
$BASE_URL       = "http://forever_r1.local/";


?>