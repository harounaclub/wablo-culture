<?php

/*
 * ======================================================
 * Database Setup
 * ======================================================
 */
$DB_HOST        = "localhost";
$DB_USER        = "root";
$DB_PASSWORD    = "";
$DATABASE       = "forever";
$BASE_URL       = "http://localhost/forever/";
