<?php
/*
 * ======================================================
 * Database Setup
 * ======================================================
 */
$DB_HOST  	= "localhost";
$DB_USER  	= "root";
$DB_PASSWORD    = "Magloire123";
$DATABASE  	= "smspro";

$index_page="index.php";

$BASE_URL="http://smspro.local/";


?>