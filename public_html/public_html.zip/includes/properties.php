<?php

$ENV_PROPERTY_FILE = "env_properties/martial.php";



include_once $ENV_PROPERTY_FILE;

?>
