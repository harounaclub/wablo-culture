<?php



// First, include Requests



    

include('library/Requests.php');

// Next, make sure Requests can load internal classes
Requests::register_autoloader();



$customerID="03654";
$userName="harouna";
$userPassword="12345";
$originator="DC SERVICES";
$defDate=date("Y").date("m").date("d").date("H").date("i").date("s");
$smsText=$_GET["message"];
$recipientPhone=$_GET["tel"];


// Now let's make a request!
$request = Requests::get('http://smspro.mtn.ci/smspro/soap/messenger.asmx/HTTP_SendSms?customerID='.$customerID.'&userName='.$userName.'&userPassword='.$userPassword.'&originator='.$originator.'&messageType=Latin&defDate='.$defDate.'&blink=false&flash=false&private=true&smsText='.$smsText.'&recipientPhone='.$recipientPhone.'', array('Accept' => 'application/xml'));



    




